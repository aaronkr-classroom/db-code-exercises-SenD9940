-- 고객등급코드
CREATE TABLE class_code (
    code        INTEGER      PRIMARY KEY,
    class       VARCHAR(10)  NOT NULL,
    basis       VARCHAR(20)  NOT NULL
);

-- 직원업무코드
CREATE TABLE task_code (
    code        INTEGER      PRIMARY KEY,
    task        VARCHAR(30)  NOT NULL
);

-- 고객
CREATE TABLE customer (
    cus_id      VARCHAR(15)  PRIMARY KEY,
    name        VARCHAR(20)  NOT NULL,
    cell        CHAR(13)     NOT NULL UNIQUE,
    addr        VARCHAR(100),
    c_code      INTEGER      NOT NULL DEFAULT 3,
    CONSTRAINT fk_customer_class
        FOREIGN KEY (c_code) REFERENCES class_code(code)
);

-- 직원
CREATE TABLE staff (
    staff_id    INTEGER      PRIMARY KEY,
    name        VARCHAR(20)  NOT NULL,
    birthday    CHAR(6)      NOT NULL,
    tel         CHAR(12),
    salary      INTEGER      DEFAULT 0 CHECK (salary >= 0),
    t_code      INTEGER      NOT NULL,
    hire_date   CHAR(8)      NOT NULL,
    CONSTRAINT fk_staff_task
        FOREIGN KEY (t_code) REFERENCES task_code(code)
);

-- 여행상품
CREATE TABLE tour (
    tour_num    CHAR(8)       PRIMARY KEY,
    departure   VARCHAR(50)   NOT NULL,
    arrival     VARCHAR(50)   NOT NULL,
    program     VARCHAR(100),
    start_dt    TIMESTAMP     NOT NULL,
    end_dt      TIMESTAMP     NOT NULL,
    min_num     INTEGER       CHECK (min_num >= 1),
    max_num     INTEGER       CHECK (max_num >= min_num),
    expense     INTEGER       NOT NULL CHECK (expense >= 0),
    deposit     INTEGER       DEFAULT 0 CHECK (deposit >= 0),
    dept_yn     CHAR(1)       DEFAULT 'N' CHECK (dept_yn IN ('Y', 'N')),
    staff_id    INTEGER,
    CONSTRAINT fk_tour_staff
        FOREIGN KEY (staff_id) REFERENCES staff(staff_id),
    CONSTRAINT chk_tour_period
        CHECK (end_dt > start_dt)
);

-- 예약
CREATE TABLE reserve (
    cus_id      VARCHAR(15)   NOT NULL,
    tour_num    CHAR(8)       NOT NULL,
    res_date    DATE          DEFAULT CURRENT_DATE,
    dep_yn      CHAR(1)       DEFAULT 'N' CHECK (dep_yn IN ('Y', 'N')),
    exp_yn      CHAR(1)       DEFAULT 'N' CHECK (exp_yn IN ('Y', 'N')),
    PRIMARY KEY (cus_id, tour_num),
    CONSTRAINT fk_reserve_customer
        FOREIGN KEY (cus_id) REFERENCES customer(cus_id),
    CONSTRAINT fk_reserve_tour
        FOREIGN KEY (tour_num) REFERENCES tour(tour_num)
);

-- 운전기사
CREATE TABLE driver (
    driver_id   INTEGER      PRIMARY KEY,
    name        VARCHAR(20)  NOT NULL,
    birthday    CHAR(6)      NOT NULL,
    cell        CHAR(13)     NOT NULL UNIQUE,
    pay         INTEGER      DEFAULT 15000 CHECK (pay >= 0),
    cont_date   CHAR(8),
    cont_term   CHAR(8)
);

-- 관광버스
CREATE TABLE tour_bus (
    bus_id      INTEGER      PRIMARY KEY,
    seat        INTEGER      CHECK (seat > 0),
    del_year    INTEGER      CHECK (del_year >= 1990)
);

-- 기사 배정
CREATE TABLE assign_driver (
    tour_num    CHAR(8)      PRIMARY KEY,
    driver_id   INTEGER      NOT NULL,
    work_hour   INTEGER      DEFAULT 0 CHECK (work_hour >= 0),
    CONSTRAINT fk_assign_driver_tour
        FOREIGN KEY (tour_num) REFERENCES tour(tour_num) ON DELETE CASCADE,
    CONSTRAINT fk_assign_driver_driver
        FOREIGN KEY (driver_id) REFERENCES driver(driver_id)
);

-- 차량 배정
CREATE TABLE assign_bus (
    tour_num    CHAR(8)      PRIMARY KEY,
    bus_id      INTEGER      NOT NULL,
    CONSTRAINT fk_assign_bus_tour
        FOREIGN KEY (tour_num) REFERENCES tour(tour_num) ON DELETE CASCADE,
    CONSTRAINT fk_assign_bus_bus
        FOREIGN KEY (bus_id) REFERENCES tour_bus(bus_id)
);

INSERT INTO class_code (code, class, basis) VALUES
(1, '최우수', '누적금액 300만원 이상'),
(2, '우수',   '누적금액 100만원 이상'),
(3, '일반',   '기본 등급'),
(4, '신규',   '가입 1개월 이내'),
(5, '휴면',   '1년 이상 미예약');

INSERT INTO task_code (code, task) VALUES
(1, '여행상품관리'),
(2, '예약관리'),
(3, '관광버스배차관리'),
(4, '직원관리'),
(5, '고객관리');

INSERT INTO customer (cus_id, name, cell, addr, c_code) VALUES
('C0001', '김민수', '010-1111-2222', '서울특별시 강남구', 1),
('C0002', '이서연', '010-2222-3333', '부산광역시 해운대구', 2),
('C0003', '박지훈', '010-3333-4444', '대구광역시 수성구', 3),
('C0004', '최유진', '010-4444-5555', '광주광역시 북구', 3),
('C0005', '정도윤', '010-5555-6666', '대전광역시 유성구', 2);

INSERT INTO staff (staff_id, name, birthday, tel, salary, t_code, hire_date) VALUES
(10001, '한지민', '900101', '02-1111-1111', 3200000, 1, '20200110'),
(10002, '오세훈', '880512', '02-2222-2222', 3000000, 2, '20210315'),
(10003, '강하늘', '920720', '02-3333-3333', 3100000, 3, '20220520'),
(10004, '윤아름', '870311', '02-4444-4444', 3500000, 4, '20191201'),
(10005, '서민재', '950908', '02-5555-5555', 2900000, 5, '20230105');

INSERT INTO tour (tour_num, departure, arrival, program, start_dt, end_dt, min_num, max_num, expense, deposit, dept_yn, staff_id) VALUES
('T2026001', '서울', '제주', 'https://tour.example.com/jeju',  TIMESTAMP '2026-07-15 09:00:00', TIMESTAMP '2026-07-17 18:00:00', 10, 30, 450000, 100000, 'N', 10001),
('T2026002', '부산', '경주', 'https://tour.example.com/gyeongju', TIMESTAMP '2026-07-20 08:00:00', TIMESTAMP '2026-07-20 20:00:00',  8, 25, 120000,  30000, 'N', 10001),
('T2026003', '서울', '강릉', 'https://tour.example.com/gangneung', TIMESTAMP '2026-08-01 07:00:00', TIMESTAMP '2026-08-02 19:00:00', 10, 28, 250000,  50000, 'N', 10002),
('T2026004', '대전', '전주', 'https://tour.example.com/jeonju', TIMESTAMP '2026-08-10 08:30:00', TIMESTAMP '2026-08-10 21:00:00',  6, 20,  90000,  20000, 'Y', 10002),
('T2026005', '대구', '여수', 'https://tour.example.com/yeosu', TIMESTAMP '2026-09-05 07:30:00', TIMESTAMP '2026-09-06 18:30:00',  8, 24, 230000,  50000, 'N', 10005);

INSERT INTO reserve (cus_id, tour_num, res_date, dep_yn, exp_yn) VALUES
('C0001', 'T2026001', DATE '2026-06-01', 'Y', 'N'),
('C0002', 'T2026001', DATE '2026-06-02', 'Y', 'Y'),
('C0003', 'T2026002', DATE '2026-06-03', 'N', 'N'),
('C0004', 'T2026003', DATE '2026-06-04', 'Y', 'N'),
('C0005', 'T2026004', DATE '2026-06-05', 'Y', 'Y');

INSERT INTO driver (driver_id, name, birthday, cell, pay, cont_date, cont_term) VALUES
(20001, '김기사', '750101', '010-7777-1001', 15000, '20260101', '12개월'),
(20002, '박운전', '780305', '010-7777-1002', 16000, '20260201', '12개월'),
(20003, '이동수', '800707', '010-7777-1003', 15500, '20260301', '6개월'),
(20004, '최안전', '820912', '010-7777-1004', 17000, '20260401', '12개월'),
(20005, '정길동', '790521', '010-7777-1005', 15000, '20260501', '6개월');

INSERT INTO tour_bus (bus_id, seat, del_year) VALUES
(1, 45, 2020),
(2, 35, 2019),
(3, 28, 2021),
(4, 45, 2018),
(5, 25, 2022);

INSERT INTO assign_driver (tour_num, driver_id, work_hour) VALUES
('T2026001', 20001, 16),
('T2026002', 20002,  8),
('T2026003', 20003, 14),
('T2026004', 20004,  9),
('T2026005', 20005, 15);

INSERT INTO assign_bus (tour_num, bus_id) VALUES
('T2026001', 1),
('T2026002', 2),
('T2026003', 3),
('T2026004', 4),
('T2026005', 5);


CREATE INDEX tour_arrival_idx ON tour(arrival ASC);
CREATE INDEX driver_name_idx ON driver(name ASC);

SELECT 'TEST 1. 고객 등급 검색' AS test_title;
SELECT c.cus_id, c.name, cc.class AS customer_class
FROM customer c
JOIN class_code cc ON c.c_code = cc.code
WHERE c.cus_id = 'C0001';

SELECT 'TEST 2. 직원 담당업무 검색' AS test_title;
SELECT s.staff_id, s.name, tc.task
FROM staff s
JOIN task_code tc ON s.t_code = tc.code
WHERE s.staff_id = 10003;

SELECT 'TEST 3. 여행상품 예약 고객 검색' AS test_title;
SELECT t.tour_num, t.arrival, c.name AS customer_name, r.res_date, r.dep_yn
FROM reserve r
JOIN customer c ON r.cus_id = c.cus_id
JOIN tour t ON r.tour_num = t.tour_num
WHERE r.tour_num = 'T2026001'
ORDER BY r.res_date;

SELECT 'TEST 4. 여행상품 배정 운전기사 검색' AS test_title;
SELECT t.tour_num, t.departure, d.name AS driver_name, d.cell
FROM tour t
JOIN assign_driver ad ON t.tour_num = ad.tour_num
JOIN driver d ON ad.driver_id = d.driver_id
WHERE t.tour_num = 'T2026001';

SELECT 'TEST 5. 신규 고객 등록' AS test_title;
INSERT INTO customer (cus_id, name, cell, addr)
VALUES ('C0006', '신규고객', '010-6666-7777', '인천광역시 연수구');

SELECT cus_id, name, cell, addr, c_code
FROM customer
WHERE cus_id = 'C0006';

SELECT 'TEST 6. 직원 급여 수정' AS test_title;
UPDATE staff
SET salary = salary + 200000
WHERE staff_id = 10005;

SELECT staff_id, name, salary
FROM staff
WHERE staff_id = 10005;

SELECT 'TEST 7. 예약 정보 삭제' AS test_title;
INSERT INTO reserve (cus_id, tour_num, res_date, dep_yn, exp_yn)
VALUES ('C0006', 'T2026005', CURRENT_DATE, 'N', 'N');

DELETE FROM reserve
WHERE cus_id = 'C0006'
  AND tour_num = 'T2026005';

SELECT *
FROM reserve
WHERE cus_id = 'C0006'
  AND tour_num = 'T2026005';

SELECT '전체 고객 목록' AS list_title;
SELECT * FROM customer ORDER BY cus_id;

SELECT '전체 여행상품 목록' AS list_title;
SELECT tour_num, departure, arrival, start_dt, end_dt, expense, dept_yn
FROM tour
ORDER BY tour_num;
